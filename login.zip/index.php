<?php include("config.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Simple Registration & Login by Muneem Billah</title>
    <?php include("head.php"); ?>
</head>
<body>

<body>
  <div class="container">
    <div class="mamb_border">
      <h1 align="center">A Simple Registration & Login by Muneem Billah</h1>
      <p align="center">Hi guest, Muneem Billah thanked you for visiting this webpage.</p><br>
      <center>
      <a href="<?php echo $site_url; ?>/register.php" class="btn btn-success btn-block mamb_btn">Register</a>
      <br>OR<br><br>
      <a href="<?php echo $site_url; ?>/login.php" class="btn btn-dark btn-block mamb_btn">Login</a><br>
    </center>
    </div><!--.mamb_border-->
  </div><!--.container-->

  <div class="mamb_footer"> 
      Home
  </div><!--.mamb_footer-->

</body>
</html>
