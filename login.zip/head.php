<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="<?php echo $site_url; ?>/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo $site_url; ?>/css/mamb-style.css">
<script src="<?php echo $site_url; ?>/js/jquery.min.js"></script>
<script src="<?php echo $site_url; ?>/js/popper.min.js"></script>
<script src="<?php echo $site_url; ?>/js/bootstrap.min.js"></script>